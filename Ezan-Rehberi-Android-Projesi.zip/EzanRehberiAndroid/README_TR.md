# Ezan Rehberi – Android APK projesi

Bu proje, mevcut Ezan Rehberi web sitesini Android uygulaması içinde açan ücretsiz bir WebView uygulamasıdır.

## Özellikler
- Android ana ekranında **Ezan Rehberi** uygulama adıyla görünür.
- Siteyi uygulama penceresinde açar.
- JavaScript ve web depolama desteği açıktır.
- Geri tuşu web sayfaları arasında geri gider.
- APK, GitHub Actions ile ücretsiz kullanım kotaları dahilinde derlenebilir.

## APK oluşturma (bilgisayarsız yöntem)
1. GitHub'da ücretsiz bir hesap açın.
2. Yeni bir repository oluşturun (ör. `ezan-rehberi-android`).
3. Bu ZIP içindeki dosyaları repository'ye yükleyin.
4. GitHub repository sayfasında **Actions** sekmesine girin.
5. **Android APK Build** iş akışını seçip **Run workflow** düğmesine basın.
6. İşlem tamamlanınca çalışmanın altındaki **Artifacts** bölümünden `Ezan-Rehberi-APK` dosyasını indirin.
7. ZIP'i açıp `app-debug.apk` dosyasını Android telefonunuza gönderin ve kurun.

## Telefona kurma
APK dosyasına dokunun. Android izin isterse bu dosya yöneticisi/tarayıcı için "Bilinmeyen uygulamaları yükle" iznini açın ve kurulumu tamamlayın.

## Önemli not
Bu uygulama web sitesini çevreleyen bir Android kabıdır; sitenin kendisini APK içine kopyalamaz. Bu nedenle internet bağlantısı gerekir ve web sitesinin adresinin yayında kalması gerekir. Gönderdiğiniz adres bir `preview` adresidir; geçici olabilir. Kalıcı kullanım için sitenin kalıcı yayın adresiyle değiştirilmesi gerekir.
